﻿using Formularios_PbD.Presentacion.catalogos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios_PbD
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolSisOpe_Click(object sender, EventArgs e)
        {
            Cliente Cl = new Cliente();
            Cl.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Empleado Em = new Empleado();
            Em.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Prestamo Pr = new Prestamo();
            Pr.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Sucursal Sc = new Sucursal();
            Sc.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Municipio Mc = new Municipio();
            Mc.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Departamento Dp = new Departamento();
            Dp.Show();
        }
    }
}
