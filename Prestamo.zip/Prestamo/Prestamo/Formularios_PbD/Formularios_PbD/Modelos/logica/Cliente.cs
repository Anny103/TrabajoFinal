﻿using Formularios_PbD.Presentacion.catalogos;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Formularios_PbD.Modelos.logica
{
    internal class Cliente 
    {
        private static object c;

        public object Nombre_cliente { get; private set; }

        public static object GetC()
        {
            return c;
        }

        private static object GetNombre_cliente(Cliente cliente)
        {
            return cliente.Nombre_cliente;
        }

        private static void Model()
        {
            throw new NotImplementedException();
        }

        private static object SingleOrDefault(object v)
        {
            throw new NotImplementedException();
        }
    }
}

namespace Formularios_PbD
{
    class Db_Modelo1 : IDisposable
    {
        public object Cliente { get; internal set; }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}