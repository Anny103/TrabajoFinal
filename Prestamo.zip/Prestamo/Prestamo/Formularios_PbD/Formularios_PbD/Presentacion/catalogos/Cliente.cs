﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios_PbD.Presentacion.catalogos
{
    public partial class Cliente : Form
    {

        private void Nuevo()
        {
            txtIdCliente.Clear();
            txtCédula.Clear();
            txtNombresCliente.Clear();
            txtApellidosCliente.Clear();
            txtDependientes.Clear();
            cbNivelAcadémico.SelectedIndex = 0;
            txtDirección.Clear();
            cbEstadoCivil.SelectedIndex = 0;
            txtTelefóno.Clear();
            cbEstado.SelectedIndex = 0;
        }


        public Cliente()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void rEGISTRSRToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtIdCliente.Text.Trim() == "")
            {
                MessageBox.Show(" Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtIdCliente.Focus();
                return;
            }
            if (txtCédula.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cédula del Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtCédula.Focus();
                return;
            }
            if (txtNombresCliente.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Nombre del Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtNombresCliente.Focus();
                return;
            }
            if (txtApellidosCliente.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Apellido del Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtApellidosCliente.Focus();
                return;
            }
            if (txtDependientes.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Dependientres del Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtDependientes.Focus();
                return;
            }
            if (cbNivelAcadémico.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Nivel Académico", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                cbNivelAcadémico.Focus();
                return;
            }
            if (txtDirección.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Direción", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtDirección.Focus();
                return;
            }
            if (cbEstadoCivil.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Estado civil", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                cbEstadoCivil.Focus();
                return;
            }
            if (txtTelefóno.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Telefóno", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtTelefóno.Focus();
                return;
            }
            if (cbEstado.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Estado", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                cbEstado.Focus();
                return;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Nuevo();
        }

        private void cbEstado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
