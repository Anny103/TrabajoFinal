﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios_PbD.Presentacion.catalogos
{
    public partial class Departamento : Form
    {

        private void  Nuevo()
        {
            txtIdDepartamento.Clear();
            txtNombreDepartamento.Clear();
        }
        public Departamento()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Nuevo();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtIdDepartamento.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtIdDepartamento.Focus();
                return;
            }
            if (txtNombreDepartamento.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtNombreDepartamento.Focus();
                return;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }
    }
}
