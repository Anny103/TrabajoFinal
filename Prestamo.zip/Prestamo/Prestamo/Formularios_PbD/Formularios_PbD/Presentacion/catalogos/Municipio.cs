﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios_PbD.Presentacion.catalogos
{
    public partial class Municipio : Form
    {

        private void Nuevo()
        {
            txtIdMunicipio.Clear();
            txtNombreMunicipio.Clear();
            TxtIdDepartamento.Clear();
        }
        public Municipio()
        {
            InitializeComponent();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Nuevo();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtIdMunicipio.Text.Trim() == "")
            {
                MessageBox.Show(" Municipio ", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtIdMunicipio.Focus();
                return;
            }
            if (txtNombreMunicipio.Text.Trim() == "")
            {
                MessageBox.Show(" Nombre Municipio", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtNombreMunicipio.Focus();
                return;
            }
            if (TxtIdDepartamento.Text.Trim() == "")
            {
                MessageBox.Show(" Nombre Municipio", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                TxtIdDepartamento.Focus();
                return;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Municipio_Load(object sender, EventArgs e)
        {

        }
    }
}
