﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios_PbD.Presentacion.catalogos
{
    public partial class Prestamo : Form
    {

        private void Nuevo()
        {
            txtIdPrestamo.Clear();
            txtIdCliente.Clear();
            txtCódigoPrestamo.Clear();
            txtNombreCliente.Clear();
            txtCódigoPrestamo.Clear();
            dtpFechaPrestamo.Text = "";
            txtPlazoPrestamo.Clear();
            txtIntereses.Clear();
            txtInteresporMora.Clear();
            txtMontodeComición.Clear();
            cbEstado.SelectedIndex = 0;
            txtConceptodelPrestamo.Clear();
        }
        public Prestamo()
        {
            InitializeComponent();
        }

        private void Prestamo_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Nuevo();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtIdCliente.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                btnBuscarCliente.Focus();
                return;
            }
            if (txtCódigoPrestamo.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Código Prestamo", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtCódigoPrestamo.Focus();
                return;
            }
            if (txtPlazoPrestamo.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Plazo de Prestamo", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtPlazoPrestamo.Focus();
                return;
            }
            if (txtIntereses.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Intereses", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtIntereses.Focus();
                return;
            }
            if (txtInteresporMora.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Intereses por Mora", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtInteresporMora.Focus();
                return;
            }
            if (txtMontodeComición.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Monto de Comición", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtMontodeComición.Focus();
                return;
            }
            if (cbEstado.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Estado", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                cbEstado.Focus();
                return;
            }
            if (txtConceptodelPrestamo.Text.Trim() == "")
            {
                MessageBox.Show("Buscar por Concepto de Prestamo", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtConceptodelPrestamo.Focus();
                return;
            }


            if (txtIdPrestamo.Text.Trim() == "")
            {
                //NUEVO
            }
        }

        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            
        }
    }
}
