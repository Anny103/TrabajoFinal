﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios_PbD.Presentacion.catalogos
{
    public partial class Sucursal : Form
    {

        private void Nuevo ()
        {
            txtIdSucursal.Clear();
            txtIdDepartamento.Clear();
            txtNombreSucursal.Clear();
            txtDirección.Clear();
            txtTelefóno.Clear();
        }
        public Sucursal()
        {
            InitializeComponent();
        }

        private void Sucursal_Load(object sender, EventArgs e)
        {

        }

        private void txtTelefóno_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtNombreSucursal_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Nuevo();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtIdSucursal.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtIdSucursal.Focus();
                return;
            }
            if (txtIdDepartamento.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtIdDepartamento.Focus();
                return;
            }
            if (txtNombreSucursal.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtNombreSucursal.Focus();
                return;
            }
            if (txtDirección.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtDirección.Focus();
                return;
            }
            if (txtTelefóno.Text.Trim() == "")
            {
                MessageBox.Show("Buscar Cliente", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                txtTelefóno.Focus();
                return;
            }
        }
    }
}
